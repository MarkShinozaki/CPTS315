#!/bin/sh
# This is a comment!

python ./src/prod_reco.py